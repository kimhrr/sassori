import SwiftUI

@main
struct SmartCampusApp: App {
    var body: some Scene {
        WindowGroup {
            ControlsView()
        }
    }
}
